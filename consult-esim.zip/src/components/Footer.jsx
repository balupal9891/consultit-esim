export default function Footer() {
  return (
    <footer className="bg-gray-100 text-gray-700 text-sm py-12 px-6 border-t">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-8">
        {/* Quick Links */}
      

        {/* Policies */}
        <div>
          <h3 className="font-semibold mb-4 text-gray-800">Policies</h3>
          <ul className="space-y-2">
            <li><a href="#">Refund Policy</a></li>
            <li><a href="#">Terms of Service</a></li>
            <li><a href="#">Privacy Policy</a></li>
          
            <li><a href="#">KYC Rules</a></li>
          </ul>
        </div>

        {/* Important Links */}
        <div>
          <h3 className="font-semibold mb-4 text-gray-800">Important links</h3>
          <ul className="space-y-2">
            <li><a href="#">eSIM compatible devices for iOS</a></li>
            <li><a href="#">eSIM compatible devices for Android</a></li>
            <li><a href="#">Other eSIM compatible devices</a></li>
            <li><a href="#">eSIM delivery and activation</a></li>
            <li><a href="#">Delivery timelines</a></li>
            <li><a href="#">FAQ on eSIM</a></li>
            <li><a href="#">Partner Login</a></li>
            <li><a href="#">eSIM Technology</a></li>
          </ul>
        </div>

      </div>

      <div className="border-t mt-12 pt-6 text-center text-xs text-gray-500">
        © 2025 ConsultIt Copyright • ConsultIt CELLULAR (INTERNATIONAL) SERVICES PRIVATE LIMITED All rights reserved
      </div>
    </footer>
  );
}
